kubectl create secret generic neo4jpwd  --from-literal=NEO4J_AUTH='neo4j/Neo4j123'
